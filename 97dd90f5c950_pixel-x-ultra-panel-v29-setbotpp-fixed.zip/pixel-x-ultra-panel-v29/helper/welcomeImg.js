// ============================================================
//   helper/welcomeImg.js  –  welcome / goodbye card renderer
//   Renders a PNG card with an SVG template, via sharp.
//   Missing sharp or a render failure returns null so the caller
//   can fall back to a plain text message.
// ============================================================
'use strict';

const BRAND_BG = '#0b0b0f';
const BRAND_ACCENT = '#25d366';

function esc(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function truncate(text, max) {
  const s = String(text == null ? '' : text);
  return s.length > max ? s.slice(0, max - 1) + '…' : s;
}

/**
 * Build a welcome card.
 * @param {object} opts
 * @param {string} opts.title       group or chat name
 * @param {string} opts.subtitle    e.g. "welcome" / "goodbye"
 * @param {string} [opts.member]    participant number or name
 * @param {number} [opts.width]
 * @param {number} [opts.height]
 * @returns {Promise<Buffer|null>}
 */
async function generateWelcomeCard(opts = {}) {
  let sharp;
  try {
    sharp = require('sharp');
  } catch {
    return null;
  }

  const width = Math.max(320, Number(opts.width) || 1024);
  const height = Math.max(160, Number(opts.height) || 512);
  const title = esc(truncate(opts.title || 'Group', 34));
  const subtitle = esc(truncate(opts.subtitle || 'WELCOME', 24).toUpperCase());
  const member = esc(truncate(opts.member || '', 30));

  const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${BRAND_BG}"/>
      <stop offset="100%" stop-color="#141420"/>
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="url(#bg)"/>
  <rect x="0" y="0" width="100%" height="8" fill="${BRAND_ACCENT}"/>
  <text x="50%" y="38%" text-anchor="middle" fill="${BRAND_ACCENT}"
        font-family="DejaVu Sans, Arial, sans-serif" font-size="${Math.round(width / 18)}"
        font-weight="bold" letter-spacing="4">${subtitle}</text>
  <text x="50%" y="55%" text-anchor="middle" fill="#ffffff"
        font-family="DejaVu Sans, Arial, sans-serif" font-size="${Math.round(width / 22)}"
        font-weight="bold">${title}</text>
  <text x="50%" y="68%" text-anchor="middle" fill="#9aa0a6"
        font-family="DejaVu Sans, Arial, sans-serif" font-size="${Math.round(width / 34)}">${member}</text>
  <text x="50%" y="90%" text-anchor="middle" fill="#4a4a55"
        font-family="DejaVu Sans, Arial, sans-serif" font-size="${Math.round(width / 44)}">PIXEL X ULTRA</text>
</svg>`;

  try {
    return await sharp(Buffer.from(svg)).png().toBuffer();
  } catch {
    return null;
  }
}

module.exports = { generateWelcomeCard };
